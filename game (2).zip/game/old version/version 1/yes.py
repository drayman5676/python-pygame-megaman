import pygame
import spritesheets

pygame.init()

SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Spritesheets')

sprite_sheet_image = pygame.image.load('Gunner_Yellow_Run.png').convert_alpha()
sprite_sheet = spritesheet.Spritesheet(sprite_sheet_image)

BG = (50, 50, 50)
Black = (0,0,0)

animation_list = []
animation_steps = 4

for x in range(animation_steps):
    animation_list.append(get_image(sprite_sheet_image, 0, 40, 47, 3, Black))

run = True
while run:

    
    screen.fill(BG)

    for x in range(animation_steps):
        screen.blit(frame_0, (0, 0))
    screen.blit(frame_1, (115, 0))
    screen.blit(frame_2, (250, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    pygame.display.update()

pygame.quit()
        
