import pygame
import os
from guizero import App, PushButton, Window,Text, TextBox
from os.path import join, isfile
from os import listdir

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
run = False


player = pygame.Rect((300, 250, 50, 50))

class loadsprite(pygame.sprite.Sprite):
    def __init__(self,x,y,image,health):
        super().__init__()
        self.health = health
        self.x = x
        self.y = y

        self.srite = image
        self.current_frame = 0

        self.image = self.sprite[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
        self.animation_speed = 0.2
        self.animation_counter = 0
        self.mask = pygame.mask.from_surface(self.image)

def load_sprite (dir1, file, w, h):
    path = join("assets", dir1, file)
    sprite_sheet = pygame.image.load(path).convert_alpha()

    sprites = []
    for i in range(sprite_sheet.get_width() // w):
        surface = pygame.Surface((w, h), pygame.SRCALHA, 32)
        rect = pygame.Rect(i * w, 0, w, h)
        surface.blit(sprite_sheet, (0, 0), rect)

        sprites.append(pygame.transform.scale2x(surface))

    return sprites

size = (1000, 600)
run = True
fps = 60

class person(loadsprite):
    def add(self):
        players.add(self)
    def animate(self):
        self.animation_counter += self.animation_speed
        if self.animation_counter >= 1:
            self.animation_counter = 0
            self.current_frame += 1
            if self.current_frame>= len(self.sprite):
                self.current_frame = 0
            self.image = self.sprite[self.current_frame]
    def run(self):
        run = load_sprite('Gunner_Yellow_Run', 11, 14)
        

pygame.init()

def do_nothing():
    app.destroy()
    main_loop()


def main_loop():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    run = True
    while run:

        screen.fill((0,0,0))
        pygame.draw.rect(screen, (255, 0, 0), player)

        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] == True:
            player.move_ip(-1, 0)
        elif key[pygame.K_RIGHT] == True:
            player.move_ip(1, 0)
        elif key[pygame.K_UP] == True:
            player.move_ip(0, -1)
        elif key[pygame.K_DOWN] == True:
            player.move_ip(0, 1)

    

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False 

        pygame.display.update()

    pygame.quit()

app = App(title="Main window")
text = Text(app, text='enter name', align = "top")
text_box = TextBox(app, text="enter name", align = "top") 

button = PushButton(app,text="Start Game",command=do_nothing)
app.display()
