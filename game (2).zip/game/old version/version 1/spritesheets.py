import pygame
import spritesheet

pygame.init()

SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Spritesheets')

sprite_sheet_image = pygame.image.load('Gunner_Yellow_Run.png').convert_alpha()
sprite_sheet = spritesheet.spritesheet(sprite_sheet_image)

BG = (50, 50, 50)
Black = (0,0,0)

##class spritesheet():
##    def __init__(self, image):
##        self.sheet = image
##    def get_image(self, frame, width, height, scale, colour):
##        image = pygame.Surface((width, height)).convert_alpha()
##        image.blit(self.sheet, (0, 0), ((frame * width), 0, width, height))
##        image = pygame.transform.scale(image, (width * scale, height * scale))
##        image.set_colorkey(colour)
##
##        return image

animation_list = []
animation_steps = 6
last_update = pygame.time.get_ticks()
animation_cooldown = 90
frame = 0

for x in range(animation_steps):
    animation_list.append(sprite_sheet.get_image( x, 48, 51, 3, Black))
##frame_0 = get_image(sprite_sheet_image, 0, 40, 47, 3, Black)
##frame_1 = get_image(sprite_sheet_image, 1, 44, 47, 3, Black)
##frame_2 = get_image(sprite_sheet_image, 2, 48, 47, 3, Black)
##frame_3 = get_image(sprite_sheet_image, 3, 48, 47, 3, Black)
##frame_4 = get_image(sprite_sheet_image, 4, 48, 47, 3, Black)
##frame_5 = get_image(sprite_sheet_image, 5, 48, 47, 3, Black)
    

run = True
while run:

    
    screen.fill(BG)

    current_time = pygame.time.get_ticks()
    if current_time - last_update >= animation_cooldown:
        frame +=1
        last_update = current_time
        if frame >= len(animation_list):
            frame = 0

    
    screen.blit(animation_list[frame], (0, 0))

    

    ###screen.blit(sprite_sheet_image, (0, 0))
##    screen.blit(frame_0, (0, 0))
##    screen.blit(frame_1, (115, 0))
##    screen.blit(frame_2, (250, 0))
##    screen.blit(frame_3, (295, 0))
##    screen.blit(frame_4, (340, 0))
##    screen.blit(frame_5, (390, 0))
 

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    pygame.display.update()

pygame.quit()
