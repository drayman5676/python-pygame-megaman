import pygame

pygame.init()

SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))# create window
pygame.display.set_caption('window')



BG = (0, 0, 0)# creates colour of back ground

run = True
while run:
    
    screen.fill(BG)


    for event in pygame.event.get():
        if event.type == pygame.QUIT: # close window
            run = False

    pygame.display.update()

pygame.quit()
