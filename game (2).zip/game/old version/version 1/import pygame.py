import pygame
import spritesheets
#import ihss.py

pygame.init()

SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Spritesheets')

sprite_sheet_image = pygame.image.load('Gunner_Yellow_Idle.png').convert_alpha()

BG = (50, 50, 50)
Black = (0,0,0)

#def get_image(sheet, frame, width, height, scale, colour):
#    image = pygame.Surface((width, height)).convert_alpha()
#    image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
#    image = pygame.transform.scale(image, (width * scale, height * scale))
#    image.set_colorkey(colour)

    #return image
animation_list = []
animation_steps = 5
last_update = pygame.time.get_ticks()
animation_cooldown = 500
frame = 0

for x in range(animation_steps):
    animation_list.append(sprite_sheet.get_image( x, 48, 51, 3, Black))
    

run = True
while run:

    
    screen.fill(BG)

    cureent_time = pygame.time.get_ticks()
    if current_time - last_update >= animation_cooldown:
        frame += 1
        last_update = current_time
    ###screen.blit(sprite_sheet_image, (0, 0))

    screen.blit(animation_list[frame], (0, 0))


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    pygame.display.update()

pygame.quit()
