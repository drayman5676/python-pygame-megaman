import pygame
import os
from os import listdir
from os.path import isfile, join

#~~~~~~~~~~~
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
vel = 5
#~~~~~~~~~~~

##def Game(window, background):

def flip(sprites):
    return[pygame.transform.flip(sprite, True, False) for sprite in sprites]


def load_Sprite(dir1,  file, w,h, direction = False):
    path = join ('assets/',dir1,  file)
    sprite_sheet = pygame.image.load(path).convert_alpha()

    all_sprites = {}

    sprites = []
    for i in range(sprite_sheet.get_width() // w):
        surface = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * w, 0, w, h)
        surface.blit(sprite_sheet, (0, 0), rect)
        sprites.append(pygame.transform.scale2x(surface))


            
    return sprites

def get_block():
    path = join('assets/floor','flooring 2.png')
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((48, 48),pygame.SRCALPHA, 32)
    rect = pygame.Rect(550, 41, 48, 48)
    surface.blit(image,(0, 0),rect)
    return (surface)

class Object(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, name = None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name

    def draw(self, win):
        win.blit(self.image, (self.rect.x, self.rect.y))

class Block(Object):
    def __init__(self, x, y):
        super().__init__(x, y, 48, 48)
        block = get_block()
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)

    
    
    
                            
    

class Main(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.current_frame = 0
        self.sprite = image
        self.image = self.sprite[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.animation_speed = 0.2
        self.animation_counter = 0

        self.stop = True

    def move(self, vx, vy):
        self.rect.x += vx
        self.rect.y += vy
        self.stop = False    


    def animate(self, image1, image2, image3):
        #image1 is idle
        #image2 is moving
        #image3 is jumping
        if self.stop == True:
            self.sprite = image1

        elif self.x > 0:
            self.sprite = image2

        else:
            self.sprite = image3

        
        self.animation_counter += self.animation_speed
        if self.animation_counter >= 1:
            self.animation_counter = 0
            self.current_frame += 1
            if self.current_frame >= len(self.sprite):
                self.current_frame = 0
            self.image = self.sprite[self.current_frame]

    def pots(self, key):
        if not key[pygame.K_LEFT] and not key[pygame.K_RIGHT]:
            self.stop = True


#~~~~~
pygame.init
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

mainChrIdle = load_Sprite('player', 'Gunner_Yellow_Idle.png', 48, 48)#image1
mainChrRun = load_Sprite('player', 'Gunner_Yellow_Run.png', 48, 48)#image2
mainChrJump = load_Sprite('player','Gunner_Yellow_Jump.png', 48, 48)#image3

main = Main( 300, 300, mainChrIdle)

bob = pygame.sprite.Group()
bob.add(main)

floor = [Block(i * 48, SCREEN_HEIGHT - 48) for i in range (- SCREEN_WIDTH // 48, SCREEN_WIDTH * 2 // 48)]
block1 = Block(0, SCREEN_HEIGHT - 48 * 4)
Objects = [ * floor]

run = True
while run:
    key = pygame.key.get_pressed()

    if key[pygame.K_LEFT] == True:
        main.move(-5, 0)
    elif key[pygame.K_RIGHT] == True:
        main.move(5, 0)
    elif key[pygame.K_UP] == True:
        main.move(0, -5)
    elif key[pygame.K_DOWN] == True:
        main.move(0, 5)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    main.pots(key)
    
    screen.fill((0,0,0))
    bob.draw(screen)
    ##Objects.draw()
    block1.draw(screen)
    main.animate(mainChrIdle,mainChrRun,mainChrJump)
    pygame.display.update()
    clock.tick(60)


pygame.quit()
