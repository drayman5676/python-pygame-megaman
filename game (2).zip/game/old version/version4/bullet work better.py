import pygame
import os
from os import listdir
from os.path import isfile, join
pygame.init()
#~~~~~~~~~~~
white = (255, 255, 255)

SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
vel = 5
TotatBullets = 10
main_shoot = True
#~~~~~~~~~~~

gain_bullet = pygame.USEREVENT + 1
pygame.time.set_timer(gain_bullet, 1000)

shoot_delay = pygame.USEREVENT + 2
pygame.time.set_timer(shoot_delay, 200)


def flip(sprites):
    return[pygame.transform.flip(sprite, True, False) for sprite in sprites]


def load_Sprite(dir1,  file, w,h, direction = False):
    path = join ('assets/',dir1, file)
    sprite_sheet = pygame.image.load(path).convert_alpha()

    all_sprites = {}

    sprites = []
    for i in range(sprite_sheet.get_width() // w):
        surface = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * w, 0, w, h)
        surface.blit(sprite_sheet, (0, 0), rect)
        sprites.append(pygame.transform.scale2x(surface))

        if direction:
            all_sprites[image.replace('.png')+ '_right'] = sprites
            all_sprites[image.replace('.png')+ '_left'] = flip(sprites)
            
    return sprites

def get_block():
    path = join('assets/','flooring 2.png')
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((48, 48),pygame.SRCALPHA, 32)
    rect = pygame.Rect(550, 41, 48, 48)
    surface.blit(image,(0, 0),rect)
    return (surface)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([5,5])
        self.image.fill(white)

        self.image = pygame.transform.scale(self.image, (5,5))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x += 5

   # def kill(self):
       # BulletGroup.remove(self)

class Object(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, name = None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name

    def draw(self, win):
        win.blit(self.image, (self.rect.x, self.rect.y))

class Block(Object):
    def __init__(self, x, y):
        super().__init__(x, y, 48, 48)
        block = get_block()
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)

    
    
    
                            
    

class Main(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.current_frame = 0
        self.sprite = image
        self.image = self.sprite[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.animation_speed = 0.2
        self.animation_counter = 0

        self.stop = True

    def move(self, vx, vy):
        self.rect.x += vx
        self.rect.y += vy
        self.stop = False    


    def animate(self, image1, image2, image3):
        #image1 is idle
        #image2 is moving
        #image3 is jumping
        if self.stop == True:
            self.sprite = image1

        elif self.x > 0:
            self.sprite = image2

        else:
            self.sprite = image3

        
        self.animation_counter += self.animation_speed
        if self.animation_counter >= 1:
            self.animation_counter = 0
            self.current_frame += 1
            if self.current_frame >= len(self.sprite):
                self.current_frame = 0
            self.image = self.sprite[self.current_frame]

    def MoveRight(self, vx):
        self.vx = vel
        if self.direction != 'right':
            self.direction = 'right'
            self.aniamtion_count = 0
    

 
            
            

    

    def pots(self, key):
        if not key[pygame.K_LEFT] and not key[pygame.K_RIGHT]:
            self.stop = True


#~~~~~
pygame.init
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

mainChrIdle = load_Sprite('player', 'Gunner_Yellow_Idle.png', 48, 48 )
mainChrRun = load_Sprite('player', 'Gunner_Yellow_Run.png', 48, 48 )
mainChrJump = load_Sprite('player','Gunner_Yellow_Jump.png', 48, 48)

main = Main( 300, 300, mainChrIdle)

bob = pygame.sprite.Group()
bob.add(main)

BulletGroup = pygame.sprite.Group()


floor = [Block(i * 48, SCREEN_HEIGHT - 48) for i in range (- SCREEN_WIDTH // 48, SCREEN_WIDTH * 2 // 48)]
block1 = Block(0, SCREEN_HEIGHT - 48 * 4)
Objects = [ * floor]

run = True
while run:
    key = pygame.key.get_pressed()

    if key[pygame.K_LEFT] == True:
        main.move(-5, 0)
    elif key[pygame.K_RIGHT] == True:
        main.move(5, 0)
    elif key[pygame.K_UP] == True:
        main.move(0, -5)
    elif key[pygame.K_DOWN] == True:
        main.move(0, 5)
    if key[pygame.K_SPACE] == True and main_shoot == True and TotatBullets >0:
        TotatBullets -= 1
        main_shoot = False
        bullet = Bullet(main.rect.x+72, main.rect.y+ 40)
        ##bullet.rect.x = main.rect.x+72
        ##bullet.rect.y = main.rect.y+ 40
        BulletGroup.add(bullet)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == gain_bullet and TotatBullets < 10:
            TotatBullets += 1
        if event.type == shoot_delay:
            main_shoot = True
            

    for bullet in BulletGroup:
#        print("yes")
        bullet.update()
        if bullet.rect.x > 1000:
            bullet.kill()
    main.pots(key)
    
    screen.fill((0,0,0))
    bob.draw(screen)
    ##Objects.draw()
    block1.draw(screen)
    main.animate(mainChrIdle,mainChrRun,mainChrJump)
    BulletGroup.draw(screen)
    #BulletGroup.update()
    pygame.display.update()
    clock.tick(60)


pygame.quit()
