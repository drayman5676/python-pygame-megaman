
import pygame
import os
import sqlite3
from os import listdir
from os.path import isfile, join
pygame.init()
pygame.font.init()

#~~~~~~~~~~~
white = (255, 255, 255)

ScreenType = 0
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
vel = 9
TotalBullets = 5
main_shoot = True
MaxAmmo = 30
Health = 100

jumping = False

gravity = 1
JumpHeight = 20
velocity = JumpHeight

#~~~~~~~~~~~

gain_bullet = pygame.USEREVENT + 1
pygame.time.set_timer(gain_bullet, 3000)

shoot_delay = pygame.USEREVENT + 2
pygame.time.set_timer(shoot_delay, 200)

background = pygame.image.load("assets/background/citybackground.png")
MainMenu = pygame.image.load("assets/background/main_menu1.png")

#pygame.mixer.init()

#MainSound = pygame.mixer.Sound("assets/sound/HomeScreenMusic.mp3")
#pygame.mixer.music.load("assets/sound/LevelMusic.MP3")
#pygame.mixer.music.load("assets/sound/mainmusic.mid")
#pygame.mixer.music.set_volume(0.4)
#pygame.mixer.music.play(loops = -1)

font = pygame.font.Font('assets/font/Retro.ttf',50)

def Text(MaxAmmo, Colour,X, Y):
    Text = font.render(MaxAmmo, True, Colour)
    screen.blit(Text,[X,Y])


def flip(sprites):
    return[pygame.transform.flip(sprite, True, False) for sprite in sprites]


def load_Sprite(dir1,  file, w,h, direction = False):
    path = join ('assets/',dir1, file)
    sprite_sheet = pygame.image.load(path).convert_alpha()

    all_sprites = {}

    sprites = []
    for i in range(sprite_sheet.get_width() // w):
        surface = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * w, 0, w, h)
        surface.blit(sprite_sheet, (0, 0), rect)
        sprites.append(pygame.transform.scale2x(surface))

        if direction:
            #all_sprites[image.replace('.png')+ '_right'] = sprites
            all_sprites[image.replace('.png')+ '_left'] = flip(sprites)
            
    return sprites

def get_block():
    path = join('assets/floor','flooring 2.png')
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((48, 48),pygame.SRCALPHA, 32)
    rect = pygame.Rect(550, 41, 48, 48)
    surface.blit(image,(00, 00),rect)
    return (surface)


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, flip):
        super().__init__()
        #pygame.mixer.music.unload()

        path = join('assets/ammo','Bullet.png')
        self.image = pygame.image.load(path).convert_alpha()

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.flip = flip
    def update(self):
        if self.flip == False:
            self.rect.x += vel

        if self.flip == True:
            self.rect.x -= vel                
            self.image = pygame.transform.flip(self.image, True, False)

   # def kill(self):
       # BulletGroup.remove(self)

class Object(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, name = None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))

class Block(Object):
    def __init__(self, x, y):
        super().__init__(x, y, 48, 48)
        self.block = get_block()
        #self.x = x
        #self.y = y
        #block.rect = block.get_rect()
        #block.rect.centre = (x,y)
        self.image.blit(self.block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
    def draws(self):
        self.image.blit(self.block, (self.x, self.y))

class Button(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
        path = join('assets/buttons','buttons.png')
        self.image = pygame.image.load(path).convert_alpha()
        
        
class ammo(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        path = join('assets/ammo','ammobox.png')
        self.image = pygame.image.load(path).convert_alpha()

def spike_get():
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((48, 48),pygame.SRCALPHA, 32)
    rect = pygame.Rect(550, 41, 48, 21)
    surface.blit(image,(00, 00),rect)
    return (surface)

class spike(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load('assets/traps/spike.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.mask = pygame.mask.from_surface(self.image)
        
    def draws(self):
        screen.blit(self.image, self.rect)
    
                            
class Main(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.current_frame = 0
        self.sprite = image
        self.image = self.sprite[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_speed = 0.2
        self.animation_counter = 0

        self.stop = True

        self.flip = False
        
    def move(self, vx, vy):
        self.rect.x += vx
        self.rect.y += vy
        self.stop = False
        if vx < 0:
            self.flip = True

        if vx > 0:
            self.flip = False


    def animate(self, image1, image2, image3):
        #image1 is idle
        #image2 is moving
        #image3 is jumping
        if self.stop == True:
            self.sprite = image1
            

        elif self.x > 0:
            self.sprite = image2
           

        if jumping == True:
            self.sprite = image3
           

        
        self.animation_counter += self.animation_speed
        if self.animation_counter >= 1:
            self.animation_counter = 0
            self.current_frame += 1
            if self.current_frame >= len(self.sprite):
                self.current_frame = 0
            self.image = self.sprite[self.current_frame]
            self.mask = pygame.mask.from_surface(self.image)

            if self.flip == True:
                
                self.image = pygame.transform.flip(self.image, True, False)

##    def MoveRight(self, vx):
##        self.flip = False
##        self.vx = vel
##        if self.direction != 'right':
##            self.direction = 'right'
##            self.aniamtion_count = 0
##            
##    def MoveLeft(self):
##        self.flip = True
##        self.vx = vel
##        if self.direction != 'left':
##            self.direction = 'left'
##            self.animation_count = 0

 
            
            

    

    def pots(self, key):
        if not key[pygame.K_LEFT] and not key[pygame.K_RIGHT]:
            self.stop = True


#~~~~~
pygame.init
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

mainChrIdle = load_Sprite('player', 'Gunner_Yellow_Idle.png', 48, 48 )
mainChrRun = load_Sprite('player', 'Gunner_Yellow_Run.png', 48, 48 )
mainChrJump = load_Sprite('player','Gunner_Yellow_Jump.png', 48, 48)


main = Main( 25, 580, mainChrIdle)

bob = pygame.sprite.Group()
bob.add(main)

BulletGroup = pygame.sprite.Group()

spikes = spike(235,588)  

SpikeGroup = pygame.sprite.Group()
SpikeGroup.add(spikes)


#floors = pygame.sprite.Group()
blockGroup = pygame.sprite.Group()
#for i in range(1,10):
floor = [Block(i * 48, SCREEN_HEIGHT - 48) for i in range (- SCREEN_WIDTH // 48, SCREEN_WIDTH * 2 // 48)]
for i in range(0,180):
    blocks = Block(46 * i,  SCREEN_HEIGHT - 48 * 4)
    blockGroup.add(blocks)

Objects = [ *floor, ]

time = pygame.time.get_ticks()

run = True
while run:


    
    key = pygame.key.get_pressed()

    if key[pygame.K_LEFT] == True:
        main.move(-5, 0)
    elif key[pygame.K_RIGHT] == True:
        main.move(5, 0)
    elif key[pygame.K_UP] == True:
        jumping = True
    if jumping:
        main.rect.y -= velocity
        velocity -= gravity
        if velocity < - JumpHeight:
            jumping = False
            velocity = JumpHeight
        
        
    #elif key[pygame.K_DOWN] == True:
     #  main.move(0, 5)
        
    if key[pygame.K_SPACE] == True and main_shoot == True and TotalBullets >0:
        TotalBullets -= 1
        MaxAmmo -= 1
        main_shoot = False
        bullet = Bullet(main.rect.x+52, main.rect.y+ 40, main.flip)
        #bullet.flip = Bullet(main.rect.x+32, main.rect.y+40)
        ##bullet.rect.x = main.rect.x+72
        ##bullet.rect.y = main.rect.y+ 40
        BulletGroup.add(bullet)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == gain_bullet and TotalBullets < 5:
            TotalBullets = 5
            
        if MaxAmmo == 0:
            TotalBullets = -1
        if event.type == shoot_delay:
            main_shoot = True
            
    if Health == 0:
        pygame.quit()
        con = sqlite3.connect("game.db")
        cursorObj = con.cursor()
        Username = input('Enter Username')
        if len(Username) != 3:
            print('Username needs to be 3 letters')
        Time = input('Your time was' + str(dt))
        entities = (Username, Time)
        cursorObj.execute('INSERT INTO leaderboard(Username, TimeVal) VALUES (?,?)', entities)
        con.commit()

    
        
    if pygame.sprite.collide_mask(spikes,main):
        Health = 0

    
    #if Health == 0:
    #    screen.blit(death,(0,0))        
            
    if ScreenType == 0:#menu
        screen.blit(MainMenu,(0,0))# draw background
        Text('The Second Amendment', white, 530, 470) 
        if key[pygame.K_RETURN] == True:
            ScreenType = ScreenType + 1
        
    
    if ScreenType == 1:#1stlevel
        screen.blit(background,(0,0))# draw background
        time2 = pygame.time.get_ticks()
        dt = (time2 - time)/1000
        ##print(dt)
        if key[pygame.K_q] == True:
            ScreenType = 0


        
        
        for bullet in BulletGroup:
#            print("yes")
            bullet.update()
            if bullet.rect.x > 1400:
                bullet.kill()
        main.pots(key)

   
    
        BulletGroup.draw(screen)
        bob.draw(screen)# draws character
        #Objects.draw()
        blockGroup.draw(screen)
        #block2.draw(screen)
        #blockGroup.draw(screen)
        main.animate(mainChrIdle,mainChrRun,mainChrJump)
        SpikeGroup.draw(screen)
        Text('Ammo',white, 10,40)
        Text(str(MaxAmmo),white, 130,40)
        Text('Time' + str(dt), white, 1150, 40)
        Text('Health ' + str(Health), white, 600, 40)
        #BulletGroup.update()
        #print(ticks)
        
        
##      for floor in floors:
##            floor.draw(screen)
    pygame.display.update()
    clock.tick(60)


pygame.quit()

