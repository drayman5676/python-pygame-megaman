import pygame
import os
from guizero import App, PushButton, Window,Text, TextBox
from os.path import join, isfile
from os import listdir

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
run = False
Black = (0,0,0)
#~~~~~~~~~~~~~~~~



#shapes
player = pygame.Rect((300, 250, 50, 50))


#~~~~~~~~

#~pygame~
pygame.init()

#~~~~~



def do_nothing():
    app.destroy()
    main_loop()


def main_loop():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    run = True
    while run:

        key = pygame.key.get_pressed()
        
        if key[pygame.K_LEFT] == True:
            player.move_ip(-1, 0)
        elif key[pygame.K_RIGHT] == True:
            player.move_ip(1, 0)
        elif key[pygame.K_UP] == True:
            player.move_ip(0, -1)
        elif key[pygame.K_DOWN] == True:
            player.move_ip(0, 1)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False 

        screen.fill((0,0,0))
        pygame.draw.rect(screen, (255, 0, 0), player)


    

    

        pygame.display.update()
##        clock.tick(fps)

    pygame.quit()



#~~guizero~~~#
app = App(title="Main window")
text = Text(app, text='enter name', align = "top")
text_box = TextBox(app, text="enter name", align = "top") 

button = PushButton(app,text="Start Game",command=do_nothing)
app.display()

#~~~~~~~~~~~~~~#













