import pygame
import os
from os import listdir
from os.path import isfile, join
pygame.init()
#~~~~~~~~~~~
white = (255, 255, 255)

ScreenType = 0
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
vel = 9
TotalBullets = 5
main_shoot = True
MaxAmmo = 30
#~~~~~~~~~~~

gain_bullet = pygame.USEREVENT + 1
pygame.time.set_timer(gain_bullet, 3000)

shoot_delay = pygame.USEREVENT + 2
pygame.time.set_timer(shoot_delay, 200)

background = pygame.image.load("assets/background/citybackground.png")
MainMenu = pygame.image.load("assets/background/mainmenu.png")




def flip(sprites):
    return[pygame.transform.flip(sprite, True, False) for sprite in sprites]


def load_Sprite(dir1,  file, w,h, direction = False):
    path = join ('assets/',dir1, file)
    sprite_sheet = pygame.image.load(path).convert_alpha()

    all_sprites = {}

    sprites = []
    for i in range(sprite_sheet.get_width() // w):
        surface = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * w, 0, w, h)
        surface.blit(sprite_sheet, (0, 0), rect)
        sprites.append(pygame.transform.scale2x(surface))

        if direction:
            all_sprites[image.replace('.png')+ '_right'] = sprites
            all_sprites[image.replace('.png')+ '_left'] = flip(sprites)
            
    return sprites

def get_block():
    path = join('assets/floor','flooring 2.png')
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((48, 48),pygame.SRCALPHA, 32)
    rect = pygame.Rect(550, 41, 48, 48)
    surface.blit(image,(00, 00),rect)
    return (surface)

class Font():
    pass

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        path = join('assets/ammo','Bullet.png')
        self.image = pygame.image.load(path).convert_alpha()

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x += vel

   # def kill(self):
       # BulletGroup.remove(self)

class Object(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, name = None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name

    def draw(self, win):
        win.blit(self.image, (self.rect.x, self.rect.y))

class Block(Object):
    def __init__(self, x, y):
        super().__init__(x, y, 48, 48)
        self.block = get_block()
        #self.x = x
        #self.y = y
        #block.rect = block.get_rect()
        #block.rect.centre = (x,y)
        self.image.blit(self.block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)
    def draws(self):
        self.image.blit(self.block, (self.x, self.y))

class Button(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        self.x = x
        self.y = y
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
        path = join('assets/buttons','buttons.png')
        self.image = pygame.image.load(path).convert_alpha()
        
        
    
    
                            
    

class Main(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.current_frame = 0
        self.sprite = image
        self.image = self.sprite[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.animation_speed = 0.2
        self.animation_counter = 0

        self.stop = True

    def move(self, vx, vy):
        self.rect.x += vx
        self.rect.y += vy
        self.stop = False    


    def animate(self, image1, image2, image3):
        #image1 is idle
        #image2 is moving
        #image3 is jumping
        if self.stop == True:
            self.sprite = image1

        elif self.x > 0:
            self.sprite = image2

        else:
            self.sprite = image3

        
        self.animation_counter += self.animation_speed
        if self.animation_counter >= 1:
            self.animation_counter = 0
            self.current_frame += 1
            if self.current_frame >= len(self.sprite):
                self.current_frame = 0
            self.image = self.sprite[self.current_frame]

    def MoveRight(self, vx):
        self.vx = vel
        if self.direction != 'right':
            self.direction = 'right'
            self.aniamtion_count = 0
    

 
            
            

    

    def pots(self, key):
        if not key[pygame.K_LEFT] and not key[pygame.K_RIGHT]:
            self.stop = True


#~~~~~
pygame.init
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

mainChrIdle = load_Sprite('player', 'Gunner_Yellow_Idle.png', 48, 48 )
mainChrRun = load_Sprite('player', 'Gunner_Yellow_Run.png', 48, 48 )
mainChrJump = load_Sprite('player','Gunner_Yellow_Jump.png', 48, 48)

main = Main( 300, 300, mainChrIdle)

bob = pygame.sprite.Group()
bob.add(main)

BulletGroup = pygame.sprite.Group()

#floors = pygame.sprite.Group()
#blockGroup = pygame.sprite.Group()
#for i in range(1,10):
floor = [Block(i * 48, SCREEN_HEIGHT - 48) for i in range (- SCREEN_WIDTH // 48, SCREEN_WIDTH * 2 // 48)]
block1 = Block(0, SCREEN_HEIGHT - 48 * 4)
Objects = [ *floor]
#    floors.add(floor)
#    blockGroup.add(block1)

run = True
while run:
    key = pygame.key.get_pressed()

    if key[pygame.K_LEFT] == True:
        main.move(-5, 0)
    elif key[pygame.K_RIGHT] == True:
        main.move(5, 0)
    elif key[pygame.K_UP] == True:
        main.move(0, -5)
    elif key[pygame.K_DOWN] == True:
        main.move(0, 5)
    if key[pygame.K_SPACE] == True and main_shoot == True and TotalBullets >0:
        TotalBullets -= 1
        main_shoot = False
        bullet = Bullet(main.rect.x+72, main.rect.y+ 40)
        ##bullet.rect.x = main.rect.x+72
        ##bullet.rect.y = main.rect.y+ 40
        BulletGroup.add(bullet)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == gain_bullet and TotalBullets == 0:
            TotalBullets = 5
            MaxAmmo -= 5
        if MaxAmmo == 0:
            TotalBullets = -1
        if event.type == shoot_delay:
            main_shoot = True
    if ScreenType == 0:#menu
        screen.blit(MainMenu,(0,0))# draw background
        if key[pygame.K_RETURN] == True:
            ScreenType = ScreenType + 1
        
    
    if ScreenType == 1:#1stlevel
        screen.blit(background,(0,0))# draw background
        if key[pygame.K_q] == True:
            ScreenType = 0
        
        for bullet in BulletGroup:
#            print("yes")
            bullet.update()
            if bullet.rect.x > 1400:
                bullet.kill()
        main.pots(key)
    
        
        bob.draw(screen)# draws character
        #Objects.draw()
        block1.draw(screen)
        #blockGroup.draw(screen)
        main.animate(mainChrIdle,mainChrRun,mainChrJump)
        BulletGroup.draw(screen)
        #BulletGroup.update()

##      for floor in floors:
##            floor.draw(screen)
    pygame.display.update()
    clock.tick(60)


pygame.quit()

