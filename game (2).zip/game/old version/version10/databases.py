import sqlite3
con = sqlite3.connect('compsci1.db')

cursorObj = con.cursor()
cursorObj.execute('SELECT * FROM TblLeaderBoard')

rows = cursorObj.fetchall()
                  
for row in rows:
    print(row)


Name = input("Enter a Name: ")
Score = int(input("Enter a Score: "))
#AccessLevel = int(input("Enter Access Level: "))

entities = (Name, Score)

cursorObj.execute('INSERT INTO TblLeaderBoard(Name, Score)VALUES(?, ?) ', entities)

con.commit()


