import pygame
import sys

# Initialize pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Create the game window
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Scrolling Screen Example")

# Load a background image (ensure it's larger than the screen dimensions)
background = pygame.image.load("assets/background/citybackground.png")  # Replace with your image file
background_width, background_height = background.get_size()

# Player setup
player = pygame.Rect(400, 300, 50, 50)  # Player is a rectangle
player_speed = 5

# Scrolling variables
scroll_x = 0
scroll_y = 0

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Get key states
    keys = pygame.key.get_pressed()

    # Move the player and adjust scrolling
    if keys[pygame.K_LEFT]:
        player.x -= player_speed
        scroll_x = max(0, min(scroll_x - player_speed, background_width - SCREEN_WIDTH))
    if keys[pygame.K_RIGHT]:
        player.x += player_speed
        scroll_x = max(0, min(scroll_x + player_speed, background_width - SCREEN_WIDTH))
    if keys[pygame.K_UP]:
        player.y -= player_speed
        scroll_y = max(0, min(scroll_y - player_speed, background_height - SCREEN_HEIGHT))
    if keys[pygame.K_DOWN]:
        player.y += player_speed
        scroll_y = max(0, min(scroll_y + player_speed, background_height - SCREEN_HEIGHT))

    # Draw the background (scrolling effect)
    screen.blit(background, (-scroll_x, -scroll_y))

    # Draw the player
    pygame.draw.rect(screen, (255, 0, 0), player)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)